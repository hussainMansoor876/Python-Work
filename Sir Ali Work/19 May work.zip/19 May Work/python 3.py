# num = list(range(0,11))
# print(num)
# magicians = ['alice', 'david', 'carolina']
# for magician in magicians:
#     print(magician.title() + ", that was a great trick!")
# num = [list(range(1,11)),list(range(11,21)),list(range(21,31))]
# print(num)
# for number in num:
#     for nums in number:
#         print(nums)
# num = list(range(12,0,-2))
# print(num)
# for r in range(1,6):
#     print(r)
# squares = []
# for value in range(1,11):
#     square = value**2
#     squares.append(square)
# print(squares)
# squares = [value**2 for value in range(1,11)]
# print(squares)
# print(max(squares))
# print(min(squares))
# print(sum((squares)))
# print(squares[10:6:-1])
# dimensions = (200, 50)
# print(dimensions[0])
# print(dimensions[1])
# n = dimensions[0]
# print(n)