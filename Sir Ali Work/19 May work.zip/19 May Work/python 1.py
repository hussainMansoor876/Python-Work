# print("Hello World")
fname = "                    Mansoor                     "
lname = "Hussain"
age = 19
detail =fname+" "+lname+" "+str(age)
print(detail.upper())
print(detail.lower())
print(detail.title().strip())
print(fname.lstrip())
print(fname.rstrip())
print(fname.strip())