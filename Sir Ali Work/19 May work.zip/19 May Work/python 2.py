# div = 3 // 2
# print(div)
# list = [1,2,3,4,5]
# print(list)
bicycles = ['trek', 'cannondale', 'redline', 'specialized']
# print(bicycles[-1])
# bicycles[0] = 'hero'
# bicycles.append('unique')
# bicycles.insert(0, 'ducati')
# print(bicycles)
# del bicycles[0]
# print(bicycles)
# bicycles.pop()
# print(bicycles)
print(sorted(bicycles))
bicycles.sort(reverse=True)
print(bicycles)